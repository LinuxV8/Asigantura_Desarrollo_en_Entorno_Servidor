<h1> No tienes permisos para esta acción </h1>
<button onclick="history.back()"> Volver </button>