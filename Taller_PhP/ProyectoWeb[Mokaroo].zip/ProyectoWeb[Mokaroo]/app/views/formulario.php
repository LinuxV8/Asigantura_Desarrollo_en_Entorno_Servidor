<hr>
<form method="POST" enctype="multipart/form-data">
    <table>
        <tr>
            <td>Id:</td>
            <td><input type="number" name="id" value="<?= $cli->id ?>" readonly></td>
            <td rowspan="7">
                <img src='<?=$ruta?>'/>
                <div>
                <input type="hidden" name="MAX_FILE_SIZE" value="3000000" /> <!--  300Kbytes -->
                <label>Subir imagen: </label> <input name="imagen" type="file" />
                </div>
            </td>
        </tr>

        <tr>
            <td>First_name:</td>
            <td><input type="text" name="first_name" value="<?= $cli->first_name ?>" autofocus></td>
        </tr>
        </tr>
        <tr>
            <td>Last_name:</td>
            <td><input type="text" name="last_name" value="<?= $cli->last_name ?>"></td>
        </tr>
        </tr>
        <tr>
            <td>E-mail:</td>
            <td><input type="email" name="email" value="<?= $cli->email ?>"></td>
        </tr>
        </tr>
        <tr>
            <td>Gender</td>
            <td><input type="text" name="gender" value="<?= $cli->gender ?>"></td>
        </tr>
        </tr>
        <tr>
            <td>Ip_address:</td>
            <td><input type="text" name="ip_address" value="<?= $cli->ip_address ?>"></td>
        </tr>
        </tr>
        <tr>
            <td>Telefono:</td>
            <td><input type="tel" name="telefono" value="<?= $cli->telefono ?>"></td>
        </tr>
        </tr>
    </table>
    <input type="submit" name="orden" value="<?= $orden ?>">
    <input type="submit" name="orden" value="Volver">
</form>